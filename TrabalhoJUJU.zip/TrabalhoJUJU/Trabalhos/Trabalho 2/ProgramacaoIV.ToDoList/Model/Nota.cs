using System.ComponentModel.DataAnnotations;

namespace ProgramacaoIV.ToDoList.Model
{
    public class Nota
    {
        public Guid Id { get; private set; } = Guid.NewGuid();

        [Required]
        [StringLength(100)]
        public string Aluno { get; set; } = string.Empty;

        [Required]
        [StringLength(100)]
        public string Disciplina { get; set; } = string.Empty;

        [Range(0, 10)]
        public decimal Valor { get; set; }

        public DateTime DataLancamento { get; set; } = DateTime.UtcNow;
    }
}
