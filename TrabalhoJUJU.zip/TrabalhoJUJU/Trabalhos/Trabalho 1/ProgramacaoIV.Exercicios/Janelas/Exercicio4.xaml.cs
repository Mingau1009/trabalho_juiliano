﻿using System.Windows;

namespace ProgramacaoIV.Exercicios.Janelas
{
    public partial class Exercicio4 : Window
    {
        public Exercicio4()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, RoutedEventArgs e)
        {
            if (int.TryParse(txtIdade.Text, out int idade))
            {
                if (idade >= 18)
                {
                    MessageBox.Show("Você é Maior de Idade!", "Resultado", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                else
                {
                    MessageBox.Show("Você é Menor de Idade!", "Resultado", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            else
            {
                MessageBox.Show("Por favor, insira uma idade válida.", "Erro", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
