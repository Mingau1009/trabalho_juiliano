﻿using System;
using System.Windows;

namespace ProgramacaoIV.Exercicios.Janelas
{
    public partial class Exercicio7 : Window
    {
        public Exercicio7()
        {
            InitializeComponent();

            for (int i = 1; i <= 12; i++)
            {
                comboBoxParcelas.Items.Add(i);
            }
            comboBoxParcelas.SelectedIndex = 0;
        }

        private void btnCalcularParcelas_Click(object sender, RoutedEventArgs e)
        {
            if (double.TryParse(txtValorTotal.Text, out double valorTotal) && valorTotal > 0)
            {
                if (comboBoxParcelas.SelectedItem != null)
                {
                    int numeroParcelas = (int)comboBoxParcelas.SelectedItem;

                    double valorParcela = valorTotal / numeroParcelas;

                    MessageBox.Show($"O valor de cada parcela é: R$ {valorParcela:F2}", "Valor da Parcela", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                else
                {
                    MessageBox.Show("Por favor, selecione o número de parcelas.", "Erro", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            else
            {
                MessageBox.Show("Por favor, insira um valor total válido.", "Erro", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
