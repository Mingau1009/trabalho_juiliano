﻿using System;
using System.Windows;

namespace ProgramacaoIV.Exercicios.Janelas
{
    public partial class Exercicio10 : Window
    {
        public Exercicio10()
        {
            InitializeComponent();
        }

        private void btnSortear_Click(object sender, RoutedEventArgs e)
        {
            Random random = new Random();

            int numeroSorteado = random.Next(1, 7); 

            if (numeroSorteado == 6)
            {
                MessageBox.Show($"Número sorteado: {numeroSorteado}\nVocê ganhou!", "Resultado", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            else
            {
                MessageBox.Show($"Número sorteado: {numeroSorteado}\nTente novamente!", "Resultado", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }
    }
}
