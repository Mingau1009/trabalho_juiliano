﻿using System;
using System.Windows;

namespace ProgramacaoIV.Exercicios.Janelas
{
    public partial class Exercicio9 : Window
    {
        private bool isLigado = false;

        public Exercicio9()
        {
            InitializeComponent();
        }

        private void btnInterruptor_Click(object sender, RoutedEventArgs e)
        {
            isLigado = !isLigado;

            if (isLigado)
            {
                btnInterruptor.Content = "Ligado";
                MessageBox.Show("O interruptor está ligado!", "Estado", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            else
            {
                btnInterruptor.Content = "Desligado";
                MessageBox.Show("O interruptor está desligado!", "Estado", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }
    }
}
