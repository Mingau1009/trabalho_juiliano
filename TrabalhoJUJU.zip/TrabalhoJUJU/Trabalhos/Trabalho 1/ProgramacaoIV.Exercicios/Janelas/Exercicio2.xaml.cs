﻿using System.Windows;

namespace ProgramacaoIV.Exercicios.Janelas
{
    /// <summary>
    /// Lógica interna para Exercicio2.xaml
    /// </summary>
    public partial class Exercicio2 : Window
    {
        public Exercicio2()
        {
            InitializeComponent();
        }

        private void btnConverter_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var temperatura = Convert.ToInt32(txtTemp.Text);

                MessageBox.Show($"Resultado = {temperatura * 9/5 + 32}");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
