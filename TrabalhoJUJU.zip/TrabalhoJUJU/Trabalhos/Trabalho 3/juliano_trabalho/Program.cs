using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddDbContext<VendasDbContext>(options =>
    options.UseMySQL(builder.Configuration.GetConnectionString("DefaultConnection")));

var app = builder.Build();

using (var scope = app.Services.CreateScope())
{
    var context = scope.ServiceProvider.GetRequiredService<VendasDbContext>();
    context.Database.EnsureCreated();
    context.Database.Migrate();
}

#region Endpoints para Transações

app.MapPost("/transacoes", async (Transacao transacao, VendasDbContext db) =>
{
    var vendedor = await db.Vendedores.FirstOrDefaultAsync(v => v.Id == transacao.VendedorId && v.IsAtivo);
    if (vendedor is null)
        return Results.BadRequest("Vendedor inválido ou inativo.");

    transacao.Id = Guid.NewGuid();
    transacao.DataTransacao = DateTime.UtcNow;
    
    db.Transacoes.Add(transacao);
    await db.SaveChangesAsync();

    return Results.Created($"/transacoes/{transacao.Id}", transacao);
});

app.MapGet("/transacoes", async (VendasDbContext db) =>
    await db.Transacoes
            .Include(t => t.Vendedor)
            .ToListAsync());

app.MapGet("/transacoes/{id}", async (Guid id, VendasDbContext db) =>
{
    var transacao = await db.Transacoes
                            .Include(t => t.Vendedor)
                            .FirstOrDefaultAsync(t => t.Id == id);
    return transacao is not null ? Results.Ok(transacao) : Results.NotFound("Transação não encontrada.");
});

#endregion

#region Endpoints para Vendedores

app.MapPost("/vendedores", async (Vendedor vendedor, VendasDbContext db) =>
{
    vendedor.Id = Guid.NewGuid();
    vendedor.IsAtivo = true;
    vendedor.DtCriacao = DateTime.UtcNow;
    vendedor.DtAtualizacao = DateTime.UtcNow;
    
    db.Vendedores.Add(vendedor);
    await db.SaveChangesAsync();
    
    return Results.Created($"/vendedores/{vendedor.Id}", vendedor);
});

app.MapGet("/vendedores", async (VendasDbContext db) =>
    await db.Vendedores.Where(v => v.IsAtivo).ToListAsync());

app.MapGet("/vendedores/{id}", async (Guid id, VendasDbContext db) =>
{
    var vendedor = await db.Vendedores.FirstOrDefaultAsync(v => v.Id == id && v.IsAtivo);
    return vendedor is not null ? Results.Ok(vendedor) : Results.NotFound("Vendedor não encontrado.");
});

app.MapPut("/vendedores/{id}", async (Guid id, Vendedor vendedorAtualizado, VendasDbContext db) =>
{
    var vendedorExistente = await db.Vendedores.FirstOrDefaultAsync(v => v.Id == id && v.IsAtivo);
    if (vendedorExistente is null)
        return Results.NotFound("Vendedor não encontrado.");

    vendedorExistente.Nome = vendedorAtualizado.Nome;
    vendedorExistente.Email = vendedorAtualizado.Email;
    vendedorExistente.DtAtualizacao = DateTime.UtcNow;

    await db.SaveChangesAsync();
    return Results.Ok(vendedorExistente);
});

app.MapDelete("/vendedores/{id}", async (Guid id, VendasDbContext db) =>
{
    var vendedor = await db.Vendedores.FirstOrDefaultAsync(v => v.Id == id && v.IsAtivo);
    if (vendedor is null)
        return Results.NotFound("Vendedor não encontrado.");

    vendedor.IsAtivo = false;
    vendedor.DtAtualizacao = DateTime.UtcNow;
    
    await db.SaveChangesAsync();
    return Results.Ok(vendedor);
});

#endregion

app.Run();

#region Modelos e Contexto

public class Transacao
{
    [Key]
    public Guid Id { get; set; }

    public decimal Valor { get; set; }
    public DateTime DataTransacao { get; set; }
    
    [Required]
    public Guid VendedorId { get; set; }
    
    public Vendedor Vendedor { get; set; }
}

public class Vendedor
{
    [Key]
    public Guid Id { get; set; }
    
    [Required(ErrorMessage = "O nome é obrigatório.")]
    public string Nome { get; set; }
    
    [Required(ErrorMessage = "O email é obrigatório.")]
    [EmailAddress(ErrorMessage = "Email inválido.")]
    public string Email { get; set; }
    
    public bool IsAtivo { get; set; } = true;
    
    public DateTime DtCriacao { get; set; }
    
    public DateTime DtAtualizacao { get; set; }
    
    public ICollection<Transacao> Transacoes { get; set; }
}

public class VendasDbContext : DbContext
{
    public VendasDbContext(DbContextOptions<VendasDbContext> options) : base(options) { }
    
    public DbSet<Transacao> Transacoes { get; set; }
    public DbSet<Vendedor> Vendedores { get; set; }
    
    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Transacao>()
            .HasOne(t => t.Vendedor)
            .WithMany(v => v.Transacoes)
            .HasForeignKey(t => t.VendedorId)
            .OnDelete(DeleteBehavior.Restrict); 
    }
}

#endregion
