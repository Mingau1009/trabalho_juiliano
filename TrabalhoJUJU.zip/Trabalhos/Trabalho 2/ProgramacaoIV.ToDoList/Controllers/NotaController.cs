using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ProgramacaoIV.ToDoList.Context;
using ProgramacaoIV.ToDoList.Model;

namespace ProgramacaoIV.ToDoList.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class NotaController : ControllerBase
    {
        private readonly NotaContext _context;

        public NotaController(NotaContext context)
        {
            _context = context;
        }

        // POST: /notas
        [HttpPost]
        public async Task<IActionResult> AdicionarNota(Nota nota)
        {
            if (!ModelState.IsValid)
                return BadRequest("Dados inv�lidos.");

            _context.Notas.Add(nota);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(ObterNotaPorId), new { id = nota.Id }, nota);
        }

        // GET: /notas
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Nota>>> ListarNotas()
        {
            return await _context.Notas.ToListAsync();
        }

        // GET: /notas/{id}
        [HttpGet("{id}")]
        public async Task<ActionResult<Nota>> ObterNotaPorId(Guid id)
        {
            var nota = await _context.Notas.FindAsync(id);

            if (nota == null)
                return NotFound();

            return nota;
        }

        // PUT: /notas/{id}
        [HttpPut("{id}")]
        public async Task<IActionResult> AtualizarNota(Guid id, Nota nota)
        {
            if (id != nota.Id)
                return BadRequest();

            _context.Entry(nota).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!NotaExists(id))
                    return NotFound();

                throw;
            }

            return NoContent();
        }

        // DELETE: /notas/{id}
        [HttpDelete("{id}")]
        public async Task<IActionResult> ExcluirNota(Guid id)
        {
            var nota = await _context.Notas.FindAsync(id);

            if (nota == null)
                return NotFound();

            _context.Notas.Remove(nota);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool NotaExists(Guid id)
        {
            return _context.Notas.Any(e => e.Id == id);
        }
    }
}
