﻿namespace ProgramacaoIV.Exercicios.Janelas
{
    public class DiasDaSemana
    {
        public enum EnumDias
        {
            Domingo,
            Segunda,
            Terca,
            Quarta,
            Quinta,
            Sexta,
            Sabado
        }
    }
}
