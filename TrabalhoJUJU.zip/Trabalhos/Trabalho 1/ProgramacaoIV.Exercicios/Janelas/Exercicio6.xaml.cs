﻿using System.Windows;

namespace ProgramacaoIV.Exercicios.Janelas
{
    public partial class Exercicio6 : Window
    {
        private int contador = 0;

        public Exercicio6()
        {
            InitializeComponent();
        }

        private void btnIncrementar_Click(object sender, RoutedEventArgs e)
        {
            contador++;

            MessageBox.Show($"Contador: {contador}", "Contador", MessageBoxButton.OK, MessageBoxImage.Information);
        }
    }
}
